You can run the file directly from the folder, or copy it to your system:

Install directions
1) Copy to C:\ProgramFiles\
2) right-click and "create shortcut" in the context menu, rename in if you want
3) Copy shortcut to C:\ProgramData\Microsoft\Windows\Start Menu\Programs
	the Shortcut will now appear on your start-menu
